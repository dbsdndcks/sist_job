package day1226;
//1. 소스코드 작성 : 대소문자 구분, 괄호는 짝으로, 문장의 끝에는 ;을 붙임.

class Hello{
	
	public static void main(String[] args){
		
		System.out.println("안녕하세요?");
		System.out.println("^0^ 포항항항");
		
		
	}//main

}//class