package day0118;

public interface B {
	public void methodB();
}
