package day0118;

public class FlyImpl implements Fly {

	@Override
	public String drivingForce() {
		return "추진력!!!";
	}

	@Override
	public String lift() {
		return "양력!!!!!!";
	}

}
