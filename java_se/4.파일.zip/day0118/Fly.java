package day0118;

/**
 * 나는 것들에 일의 목록을 정의하는 인터페이스<br>
 * 날려면 추진력과 양력이 있어야한다. 
 */
public interface Fly {
	public abstract String drivingForce();
	public abstract String lift();
}
