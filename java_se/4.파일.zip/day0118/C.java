package day0118;

/**
 * C인터페이스의 부모는 A와 B
 */
public interface C extends A, B{
	public void methodC();
}
