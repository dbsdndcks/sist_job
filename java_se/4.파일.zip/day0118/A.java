package day0118;

public interface A {
	public void methodA();
}
