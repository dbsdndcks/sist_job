package day_0109;

public class CookRamen {
	public static void main(String[] args) {
		Ramen cook = new Ramen();
		cook.setName("너구리");
		cook.setFlavor("순한 맛");
		cook.setEgg(1);
		System.out.println(cook.cook());
	}
}
