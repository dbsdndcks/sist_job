package day_0109;

/**
 * 1. 아래의 대상을 추상화하여 클래스를 생성하고, 객체화하여 사용해보세요.
 */
public class Ramen {
	private String name;
	private String flavor;
	private int egg;

	public void setName(String name) {
		if (name.equals("너구리")) {
			name = "너구리";
		} else if (name.equals("신라면")) {
			name = "신라면";
		} else if (name.equals("안성탕면")) {
			name = "안성탕면";
		}
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setFlavor(String flavor) {
		if (flavor.equals("순한맛")) {
			flavor = "순한 맛";
		} else if (flavor.equals("매운 맛")) {
			flavor = "매운 맛";
		} else if (flavor.equals("깔끔한 맛")) {
			flavor = "깔끔한 맛";
		} else {
			flavor = "순한 맛";
		}
		this.flavor = flavor;
	}

	public String getFlavor() {
		return flavor;
	}

	public void setEgg(int egg) {
		this.egg = egg;
	}

	public int getEgg() {
		return egg;
	}

	public String cook() {
		if (name.equals("너구리") || name.equals("신라면") || name.equals("안성탕면")) {
			if (egg == 0) {
				return "계란 안 넣고 " + name + flavor + " 끓이기";
			} else {
				return name + " " + flavor + " " + "계란 " + egg + " 개 넣고 끓이기";
			}
		} else {
			return "너구리 신라면 안성탕면 중에서 골라주세요";
		}
	}
}
