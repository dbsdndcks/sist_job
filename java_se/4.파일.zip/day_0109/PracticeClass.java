package day_0109;
//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
class PracticeClass {
	String num;
	String name;
	int age;
	String email;
	
	public PracticeClass (String num, String name, int age, String email){
		this.num = num;
		this.name = name;
		this.age = age;
		this.email = email;
	}
	public void print(){
		if(num.length() == 8) {
		System.out.println("학생 정보 = " + num + name + age + " 살 " + email + " 입니다.");
		}else {
			System.out.println("잘못된 학생 정보입니다.");
		}
	}
	
	public static class StudentsInfo extends PracticeClass{
		 StudentsInfo(){
			super("11111111", " 홍길동 ", 20, " aaaa@aaaaa.com");
		}
	}
	public static void main(String[] args) {
		StudentsInfo info = new StudentsInfo();
		info.print();
	}
}