package day_0109;
/**
 * V.A를 사용하여 console에 출력하는 method<br> 
 * System.out.format(), System.out.printf() - 출력 후 줄 변경을 하지 않는다. \n 사용하여 줄 변경 할 것.<br>
 * 출력 문자
 * %로 시작하는 문자 printf, format안에서 사용 가능
 * 종류	출력문자	사용법
 * 정수	%d		"%d"- 정수 값을 출력, 
 * 				%자릿수d" - 
 * 				자리를 설정하여 출력 "%6d",1221 => 6칸잡고 1221을 출력(오른쪽 정렬) 
 * 				"%-6d",1221 => 6칸 잡고 1221출력(왼쪽 정렬)
 * 문자	%c		"%c"- 문자를 출력, 
 * 불린	%b		"%b"- 불린을 출력,
 * 실수	%f		"%f"- 실수를 출력,
 * 				%f10.2f",12.1234
 * 문자열 %s		"%s"- 문자열을 출력,
 */
public class UseVariableArguments2 {
	
	public static void main(String[] args) {
		
		int year = 2024, month = 1, day = 9;
		System.out.println("오늘은 "+year+ "년 " +month+ "월 " +day+ "일 입니다.");
		System.out.format("오늘은 %d년 %d월 %d일 입니다.\n",year, month, day);//잘 안씀
		System.out.printf("%6d\n",1221);
		System.out.printf("정수 출력 : [%d][%5d][%-5d]\n",19,19,19);
		System.out.printf("문자 출력 : [%c][%5c][%-5c]\n",'A','A','A');
		System.out.printf("불린 출력 : [%b][%5b][%-5b]\n",true,true,true);
		System.out.printf("실수 출력 : [%9.4f][%.4f][%.3f]\n",2024.0109, 2024.0109, 2024.0109);	
		System.out.printf("문자열 출력 : [%s][%10s][%-10s]\n","자바", "자바", "자바");	
		
		String name = "김병년";
		int javaScore = 89;
		int oracleScore = 92;
		int htmlScore = 91;
		int sum = javaScore + oracleScore + htmlScore;
		double evg = sum / 3 ;
		
		System.out.printf("%s 님 Java SE %d 점 Oracle %d점 html %d 점 \n",name, javaScore,oracleScore,htmlScore);
		System.out.printf("총점 : %d 점 평균 %.1f 점",sum,evg);
		
		
	}//main
}//class
