package day_0109;

/**
 * MakerPen 클래스에 제공하는 기능( 일 ) 사용하기 위한 클래스 
 */
public class UseMakerPen {

	public static void main(String[] args) {
		//객체화
		MakerPen ump = new MakerPen();
		System.out.println("주소:" + ump);//6f2b958e = heap의 주소
		//변수에 값을 직접 할당 => 입력값을 체크하는 코드를 중복해서 만들어야한다.
//		ump.cap = 100;
//		if(ump.cap != 1) {
//			ump.cap = 1;
//		}
		ump.setCap(10);
		ump.setBody(1);
		ump.setColor("빨간");
		
		System.out.printf("뚜껑의 수 %d 개, 몸체의 수 %d 개, 색 %s색\n",
				ump.getCap(),ump.getBody(),ump.getColor());
		//클래스가 제공하는 기능 사용
		String result = ump.write("오늘은 눈내리는 화요일!!");
		System.out.println(result);
	}

}
