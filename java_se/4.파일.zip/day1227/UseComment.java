package day1227;

/*
이 클래스는 주석을 연습하기 위한 클래스로
자바에서는 3가지의 주석이 제공된다.
*/

class UseComment {
	//한 줄 주석
	//main method : Java Application - 단독으로 실행가능한 프로그램
	public static void main(String[] args) 	{
		System.out.println("Hello World!");
		/* 여러 줄 주석
		System.out.println("오늘은 수요일");
		System.out.println("내일은 목요일");
		*/

		System.out.println("오늘은 수요일");
		////////////////영역 분리//////////////////////////
		System.out.println("내일은 목요일");

//		char c='AB';

	}//main
}//class
