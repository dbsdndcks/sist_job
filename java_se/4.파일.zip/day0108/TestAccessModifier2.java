package day0108;

/**
 *  package 접근지정자를 가진 클래스 
 */
class TestAccessModifier2 {
	public int a;
	protected int b;
	int c;
	private int d;
}
