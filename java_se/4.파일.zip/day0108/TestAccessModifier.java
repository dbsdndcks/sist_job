package day0108;

public class TestAccessModifier {
	public int a;
	protected int b;
	int c;
	private int d;
}
