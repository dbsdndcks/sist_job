package day0123;

import javax.swing.JOptionPane;

public class HomeWork2 {

	public static void main(String[] args) {

//		String inputData=
//				JOptionPane.showInputDialog("이름을 입력주세요","홍길동");
//		
//		StringBuilder sb=new StringBuilder();
//		if("윤웅찬".equals(inputData)) {
//			sb.append("조원동의 자랑 ");
//		}
//		sb.append( inputData ).append("님");
//		
//		System.out.println( sb );	
		
	JOptionPane.showInputDialog(
			"\"이름,자바점수,오라클점수\" 입력\n\"출력\"을 입력하면 출력됩니다.\n 종료하시려면 \"Y|y\"를 입력해 주세요.");
		
	}//main

}//class
