package day0125;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

@SuppressWarnings("serial")
public class UseImageIcon extends JFrame {

	public UseImageIcon() {
		super("이미지 연습");
		
		ImageIcon ii=new ImageIcon("E:/dev/workspace/java_se/src/day0125/images/img1.png");
		ImageIcon ii2=new ImageIcon("E:/dev/workspace/java_se/src/day0125/images/img4.png");
		
		JLabel jl=new JLabel( ii );
		JButton jbtn=new JButton( ii2 ); 
		JButton jbtn2=new JButton( "클릭" ); 
		
		setLayout( null );// 수동배치
		
		jl.setBounds(100, 100, 300, 200);
		jbtn.setBounds(420, 100, 300, 200);
		jbtn2.setBounds(200, 200, 80, 30);
		
		//Frame에 컴포넌트 배치
		add( jbtn2 );
		add( jl );
		add( jbtn );
		
		setBounds(100, 100, 800, 400);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}//UseImageIcon
	
	public static void main(String[] args) {
		new UseImageIcon();
	}//main

}//class
