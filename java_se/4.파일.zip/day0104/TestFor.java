package day0104;

/**
 *for문 : 시작과 끝을 알때 사용하는 반복문<br>
 * 문법) <br>
 * for(시작값 ; 조건식(끝값) ; 증.감소식){<br>
 *  반복수행될 문장들...;<br>
 * }<br>
 *   
 */
public class TestFor {

	public static void main(String[] args) {
		//안녕하세요를 10번 출력하는 코드 작성.
		for(int i=0 ; i < 10 ; i++) {
			System.out.println("안녕하세요? "+i);
		}//end for
		
		//1에서 부터 100까지 옆으로 출력하는 코드 작성  1 2 3 4 5.. 1--
		for(int i=1 ; i < 101 ; i++) {
			System.out.print(i+ " ");
		}//end for
		
		System.out.println();
		
		//1에서부터 100까지 홀수만 옆으로 출력하는 코드 작성  1 3 5 7 .. 99 
		// 증.감식은 대상체의 값을 변화시키고 저장할 수 있는 모든 연산자를 사용할 수 있다.
		for(int i=1 ; i < 101 ; i+=2 ) { //i++ , i=i+1, i+=1
//			if( i % 2 == 1) {
			System.out.print(i+ " ");
//			}
		}//end for
		
		System.out.println();
		
		//100에서부터 1까지 옆으로 출력하는 코드 작성 
		for(int i=100 ; i > 0 ; i-- ) { //i++ , i=i+1, i+=1
			System.out.print(i+ " ");
		}//end for
		System.out.println();
		
		//1에서 부터 9까지 1씩 증가하는 값을 아래로 출력
		for(int i=1 ; i < 10 ; i++) {
			System.out.println("4 x "+i +" = "+ (i * 4) );
		}//end for
		
		System.out.println("-----------------------------");
		//main method에서 처음 입력된 값이 구구단의 범위 였을 때 ( 2 ~ 9 )
		//해당 단의 구구단을 출력하는 코드 작성. 
		
		//1 에서 부터 100까지의 합을 출력. 5050   1+ 2+3+4+5+ ... +100  : 누적합
		int sum=0; //누적합을 하기위한 변수
		
		for(int i=1 ; i < 101 ; i++) {
			sum += i; // sum= sum+i;
		}//end for
		System.out.println("1~100까지의 합은 " +  sum );
		
	}//main

}//class
