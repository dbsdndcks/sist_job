package day0117;

public non-sealed class Test1 extends TestSuper{

}
