package day0117;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class UseAnnotation {
	
	@Deprecated
	public void test() {
		System.out.println("오늘은 수요일 입니다.");
		Date date=new Date();
		System.out.println( date.getYear() );
	}//test
	
	@SuppressWarnings({"unused","rawtypes"})
	public void test2() {
//		@SuppressWarnings("unused")
		int day;
		int j;
		int k;
		
//		@SuppressWarnings("rawtypes")
		List list=new ArrayList();
	}
	
	//Override는 부모클래스가 가지고 있는 method를 자식 클래스에서 그대로 정의하는 것.
	@Override
	public String toString() {
		return "생성된 객체의 주소가 아닌 메시지";
	}

	public static void main(String[] args) {
		
		UseAnnotation ua=new UseAnnotation();
		ua.test();
		
		Date d=new Date();
		SimpleDateFormat sdf=new SimpleDateFormat();
		
		System.out.println( ua ); //내 객체 : 주소 > toString을 Override하면 내가 원하는 메시지가 출력
		System.out.println( d ); // 자바제공 객체 : 메시지
		System.out.println( sdf ); //자바제공 객체 : 주소
		
		
		
	}//main

}//class
