package day0117;

/**
 * 부모클래스가 sealed였다면 자식 클래스는 상속을 받더라도 non-sealed를 클래스 앞에 명시해야한다. 
 */
public non-sealed class Test2 extends TestSuper{

}
