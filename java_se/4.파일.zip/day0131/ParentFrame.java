package day0131;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class ParentFrame extends JFrame implements ActionListener {

	public ParentFrame() {
		super("다이얼로그 연습");
		JButton jbtn=new JButton("다이얼로그");
		
		JPanel jp=new JPanel();
		jp.add(jbtn);
		
		jbtn.addActionListener(this);
		add("Center",jp);
		setSize(500, 500);
		setVisible(true);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}//ParentFrame
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
	}//actionPerformed

	public static void main(String[] args) {
		new ParentFrame();
	}//main

}//class
