package day0131;

public class RunHomeWork {

	public static void main(String[] args) {
		new HomeWorkDesign();
	}//main

}//class
