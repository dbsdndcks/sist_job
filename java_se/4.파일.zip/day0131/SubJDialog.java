package day0131;

import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JLabel;

/**
 * 부가적인 기능을 제공하기 위해 제작하는 창 : Dialog 
 */
@SuppressWarnings("serial")
public class SubJDialog extends JDialog implements ActionListener {

	public SubJDialog( ParentFrame pf ) {//Frame의 자식창
		super(pf,"부가적인 기능",true);
		
		ImageIcon ii=new ImageIcon("E:/dev/workspace/java_se/src/day0125/images/img3.png");
		JLabel jlblBack=new JLabel("자식창에서 제공하는 이미지",ii,JLabel.CENTER);
		
	}
	
	
	@Override
	public void actionPerformed(ActionEvent e) {

	}//actionPerformed

}//class
