package day0102;

public class Work0102 {

	public static void main(String[] args) {

//문제2.
// 1-1.세 개의 정수를 저장할 수 있는 변수를 만들고, 각각의 변수에 임의의 값을 할당한다.
// 1-2.세 개의 숫자 중 가장 작은 값을 찾아서 출력하는 코드를 만들어 보세요. (삼항연산자 )
		int num=10, num2=3, num3=5;
		System.out.print(num+", "+ num2+", "+ num3+ " 수 중 가장 작은 값 :");
		System.out.println( (num < num2 && num < num3) ? 
				num : (num2 < num3 ? num2 : num3) );
		
		System.out.println(Integer.MAX_VALUE+"의 하위 2Byte 값 : "+
				(Integer.MAX_VALUE & 0x0000FFFF));
		
	}//main

}//class
