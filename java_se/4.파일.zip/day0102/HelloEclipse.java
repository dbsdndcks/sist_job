package day0102;

/**
 * 이 클래스는 이클립스를 연습하기 위한 클래스 입니다.
 */
public class HelloEclipse {

	/**
	 * Java Application : 단독으로 실행 가능한 자바 프로그램.
	 * @param args 실행에 필요한 입력 값
	 */
	public static void main(String[] args) {
		System.out.println("안녕 이클립스!!!");
		System.out.println("안녕 이클립스!!!");
		int i = 0;//지역변수 자동초기화x => 사용 err
		
		System.out.println( i );
		
		System.out.println("안녕 이클립스!!!");
		System.out.println("안녕 이클립스!!!");
		
		System.out.println( Integer.MAX_VALUE );
		
	}//main

}//class
