package day0122;

/**
 * Enumeration : 열거형 - 값을 나열하여 사용하는 데이터 형
 */
public enum Day {
	MON,TUE,WED,THU,FRI,SAT,SUN //상수로 사용되므로 대문자로  
}
