package kr.co.sist.prepared.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import kr.co.sist.vo.ZipcodeVO;

public class ZipcodeDAO {
	private static ZipcodeDAO zDAO;
	
	private ZipcodeDAO() {
		
	}
	
	public static ZipcodeDAO getInstance() {
		if(zDAO == null) {
			zDAO = new ZipcodeDAO();
		}//end if
		return zDAO;
	}//getInstance
	
	public List<ZipcodeVO>selectZipcode(String dong)throws SQLException{
		List<ZipcodeVO> list = new ArrayList<ZipcodeVO>();
		
		return list;
	}
	
}
