package kr.co.sist.prepared.evt;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JOptionPane;

import kr.co.sist.design.ZipcodeSearchDesign;

public class ZipcodeSearchDesignEvent extends WindowAdapter implements ActionListener {

	private ZipcodeSearchDesign zsd;
	
	public ZipcodeSearchDesignEvent(ZipcodeSearchDesign zsd) {
		this.zsd = zsd;
	}//ZipcodeSearchDesignEvent
	
	
	
	@Override
	public void windowClosing(WindowEvent e) {
		zsd.dispose();
	}

	@Override
	public void actionPerformed(ActionEvent ae) {
		String dong = zsd.getJtfDong().getText().trim();
		if(dong.isEmpty()) {
			JOptionPane.showMessageDialog(zsd, "동 이름은 필수 입력입니다.");
			return;
		}
		setZipcode(dong);
	}//actionPerformed
	
	private void setZipcode(String dong) {
		
	}

}//class
